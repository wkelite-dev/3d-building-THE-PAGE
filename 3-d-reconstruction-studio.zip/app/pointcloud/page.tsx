import PointCloudHero from "@/components/point-cloud-hero";

export default function PointCloudPage() {
  return (
    <main className="min-h-screen bg-[#0a0f1a]">
      <PointCloudHero />
    </main>
  );
}
