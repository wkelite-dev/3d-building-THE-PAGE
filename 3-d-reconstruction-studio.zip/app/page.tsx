"use client";

import dynamic from "next/dynamic";

const PointCloudWebGL = dynamic(
  () => import("@/components/point-cloud-webgl"),
  { ssr: false }
);

export default function Page() {
  return (
    <main className="min-h-screen bg-[#0a0f1a]">
      {/* Section 1: Point Cloud WebGL Visualizer */}
      <section className="p-4">
        <PointCloudWebGL />
      </section>

      {/* Section 2: Original Scanner App */}
      <section>
        <iframe
          src="/index.html"
          className="w-full h-screen border-0"
          title="Skaner 3D AI"
        />
      </section>
    </main>
  );
}
