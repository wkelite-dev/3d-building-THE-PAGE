"use client";

import { useRef, useEffect, useState, useCallback } from "react";

const VERTEX_SHADER = `
  attribute vec3 position;
  attribute vec3 normal;
  attribute float aScale;
  attribute float aSpeed;
  attribute float aNoise;
  
  uniform float uTime;
  uniform float uScanY;
  uniform mat4 projectionMatrix;
  uniform mat4 modelViewMatrix;
  
  varying float vScan;
  varying float vDist;
  
  void main() {
    vec3 p = position;
    
    // Breathing wave animation
    p += normal * sin(uTime * aSpeed + aNoise * 6.28) * 0.04;
    
    // Scan band calculation
    float scanDist = abs(p.y - uScanY);
    vScan = smoothstep(0.35, 0.0, scanDist);
    
    vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);
    vDist = -mvPosition.z;
    
    // Point size based on scale + scan boost, attenuated by distance
    float size = aScale * 12.0 + vScan * 8.0;
    gl_PointSize = size * (300.0 / vDist);
    
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const FRAGMENT_SHADER = `
  precision mediump float;
  
  varying float vScan;
  varying float vDist;
  
  void main() {
    // Circular point
    vec2 coord = gl_PointCoord - vec2(0.5);
    if (length(coord) > 0.5) discard;
    
    // Base colors: teal #2DD4BF to blue #3D85F5
    vec3 teal = vec3(0.176, 0.831, 0.749);
    vec3 blue = vec3(0.239, 0.522, 0.961);
    vec3 white = vec3(1.0);
    
    // Blend by distance
    float distFactor = clamp((vDist - 2.0) / 4.0, 0.0, 1.0);
    vec3 baseColor = mix(teal, blue, distFactor);
    
    // White-hot boost where scan is high
    vec3 color = mix(baseColor, white, vScan * 0.8);
    
    // Soft edge
    float alpha = 1.0 - smoothstep(0.3, 0.5, length(coord));
    alpha *= 0.7 + vScan * 0.3;
    
    gl_FragColor = vec4(color, alpha);
  }
`;

function createShader(gl: WebGLRenderingContext, type: number, source: string): WebGLShader | null {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error("Shader compile error:", gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

function createProgram(gl: WebGLRenderingContext, vs: WebGLShader, fs: WebGLShader): WebGLProgram | null {
  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error("Program link error:", gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }
  return program;
}

function generateVRGogglesPoints(count: number) {
  const positions: number[] = [];
  const normals: number[] = [];
  const scales: number[] = [];
  const speeds: number[] = [];
  const noises: number[] = [];

  const addPoint = (x: number, y: number, z: number, nx: number, ny: number, nz: number) => {
    positions.push(x, y, z);
    const len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
    normals.push(nx / len, ny / len, nz / len);
    scales.push(0.5 + Math.random() * 0.5);
    speeds.push(0.5 + Math.random() * 1.5);
    noises.push(Math.random());
  };

  // Left lens (ellipsoid cluster)
  const leftLensPoints = Math.floor(count * 0.2);
  for (let i = 0; i < leftLensPoints; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    const r = 0.35 + Math.random() * 0.05;
    const x = -0.55 + r * Math.sin(phi) * Math.cos(theta) * 1.1;
    const y = 0.05 + r * Math.sin(phi) * Math.sin(theta) * 0.9;
    const z = r * Math.cos(phi) * 0.7;
    addPoint(x, y, z, x + 0.55, y - 0.05, z);
  }

  // Right lens (ellipsoid cluster)
  const rightLensPoints = Math.floor(count * 0.2);
  for (let i = 0; i < rightLensPoints; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    const r = 0.35 + Math.random() * 0.05;
    const x = 0.55 + r * Math.sin(phi) * Math.cos(theta) * 1.1;
    const y = 0.05 + r * Math.sin(phi) * Math.sin(theta) * 0.9;
    const z = r * Math.cos(phi) * 0.7;
    addPoint(x, y, z, x - 0.55, y - 0.05, z);
  }

  // Torus rings around each lens
  const torusPoints = Math.floor(count * 0.1);
  for (let i = 0; i < torusPoints; i++) {
    const side = i % 2 === 0 ? -0.55 : 0.55;
    const angle = Math.random() * Math.PI * 2;
    const tubeAngle = Math.random() * Math.PI * 2;
    const R = 0.38;
    const r = 0.06 + Math.random() * 0.02;
    const x = side + (R + r * Math.cos(tubeAngle)) * Math.cos(angle);
    const y = 0.05 + (R + r * Math.cos(tubeAngle)) * Math.sin(angle) * 0.85;
    const z = r * Math.sin(tubeAngle) * 0.6;
    addPoint(x, y, z, Math.cos(tubeAngle) * Math.cos(angle), Math.cos(tubeAngle) * Math.sin(angle), Math.sin(tubeAngle));
  }

  // Main body/frame
  const bodyPoints = Math.floor(count * 0.2);
  for (let i = 0; i < bodyPoints; i++) {
    const t = Math.random();
    const x = (Math.random() - 0.5) * 1.8;
    const y = 0.3 + Math.random() * 0.25 - Math.abs(x) * 0.15;
    const z = -0.2 - Math.random() * 0.15 - t * 0.1;
    addPoint(x, y, z, 0, 0.5, -1);
  }

  // Bottom frame
  const bottomPoints = Math.floor(count * 0.08);
  for (let i = 0; i < bottomPoints; i++) {
    const x = (Math.random() - 0.5) * 1.6;
    const y = -0.25 + Math.random() * 0.1;
    const z = -0.15 - Math.random() * 0.1;
    addPoint(x, y, z, 0, -1, -0.3);
  }

  // Nose bridge cylinder
  const nosePoints = Math.floor(count * 0.05);
  for (let i = 0; i < nosePoints; i++) {
    const angle = Math.random() * Math.PI * 2;
    const r = 0.08 + Math.random() * 0.03;
    const x = r * Math.cos(angle);
    const y = -0.15 - Math.random() * 0.2;
    const z = 0.1 + Math.random() * 0.1;
    addPoint(x, y, z, Math.cos(angle), 0, Math.sin(angle));
  }

  // Side straps
  const strapPoints = Math.floor(count * 0.1);
  for (let i = 0; i < strapPoints; i++) {
    const side = i % 2 === 0 ? -1 : 1;
    const t = Math.random();
    const x = side * (0.9 + t * 0.4);
    const y = 0.1 + Math.sin(t * Math.PI) * 0.15;
    const z = -0.2 - t * 0.3;
    addPoint(x, y, z, side, 0, 0);
  }

  // Floating ambient particles
  const ambientPoints = count - positions.length / 3;
  for (let i = 0; i < ambientPoints; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    const r = 1.5 + Math.random() * 1.0;
    const x = r * Math.sin(phi) * Math.cos(theta);
    const y = r * Math.sin(phi) * Math.sin(theta);
    const z = r * Math.cos(phi);
    addPoint(x, y, z, x, y, z);
  }

  return {
    positions: new Float32Array(positions),
    normals: new Float32Array(normals),
    scales: new Float32Array(scales),
    speeds: new Float32Array(speeds),
    noises: new Float32Array(noises),
    count: positions.length / 3,
  };
}

export default function PointCloudWebGL() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [fps, setFps] = useState(0);
  const [vertexCount, setVertexCount] = useState(0);
  const [scanPercent, setScanPercent] = useState(0);
  
  const angleXRef = useRef(0);
  const angleYRef = useRef(0);
  const isDraggingRef = useRef(false);
  const lastMouseRef = useRef({ x: 0, y: 0 });
  const lastInteractionRef = useRef(0);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    isDraggingRef.current = true;
    lastMouseRef.current = { x: e.clientX, y: e.clientY };
    lastInteractionRef.current = performance.now();
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMouseRef.current.x;
    const dy = e.clientY - lastMouseRef.current.y;
    angleYRef.current += dx * 0.005;
    angleXRef.current = Math.max(-0.6, Math.min(0.6, angleXRef.current + dy * 0.005));
    lastMouseRef.current = { x: e.clientX, y: e.clientY };
    lastInteractionRef.current = performance.now();
  }, []);

  const handleMouseUp = useCallback(() => {
    isDraggingRef.current = false;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const gl = canvas.getContext("webgl", { alpha: false, antialias: true });
    if (!gl) {
      console.error("WebGL not supported");
      return;
    }

    // Create shaders and program
    const vs = createShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
    const fs = createShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
    if (!vs || !fs) return;

    const program = createProgram(gl, vs, fs);
    if (!program) return;

    // Generate point cloud data
    const data = generateVRGogglesPoints(20000);
    setVertexCount(data.count);

    // Create buffers
    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data.positions, gl.STATIC_DRAW);

    const normalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data.normals, gl.STATIC_DRAW);

    const scaleBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, scaleBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data.scales, gl.STATIC_DRAW);

    const speedBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, speedBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data.speeds, gl.STATIC_DRAW);

    const noiseBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, noiseBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data.noises, gl.STATIC_DRAW);

    // Get attribute locations
    const positionLoc = gl.getAttribLocation(program, "position");
    const normalLoc = gl.getAttribLocation(program, "normal");
    const scaleLoc = gl.getAttribLocation(program, "aScale");
    const speedLoc = gl.getAttribLocation(program, "aSpeed");
    const noiseLoc = gl.getAttribLocation(program, "aNoise");

    // Get uniform locations
    const uTimeLoc = gl.getUniformLocation(program, "uTime");
    const uScanYLoc = gl.getUniformLocation(program, "uScanY");
    const projectionMatrixLoc = gl.getUniformLocation(program, "projectionMatrix");
    const modelViewMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix");

    // Setup GL state
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    gl.disable(gl.DEPTH_TEST);

    // Matrix utilities
    function perspective(fov: number, aspect: number, near: number, far: number): Float32Array {
      const f = 1.0 / Math.tan(fov / 2);
      const nf = 1 / (near - far);
      return new Float32Array([
        f / aspect, 0, 0, 0,
        0, f, 0, 0,
        0, 0, (far + near) * nf, -1,
        0, 0, 2 * far * near * nf, 0,
      ]);
    }

    function multiplyMatrices(a: Float32Array, b: Float32Array): Float32Array {
      const result = new Float32Array(16);
      for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
          result[i * 4 + j] = 
            a[i * 4] * b[j] +
            a[i * 4 + 1] * b[j + 4] +
            a[i * 4 + 2] * b[j + 8] +
            a[i * 4 + 3] * b[j + 12];
        }
      }
      return result;
    }

    function rotateX(angle: number): Float32Array {
      const c = Math.cos(angle), s = Math.sin(angle);
      return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]);
    }

    function rotateY(angle: number): Float32Array {
      const c = Math.cos(angle), s = Math.sin(angle);
      return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]);
    }

    function translate(x: number, y: number, z: number): Float32Array {
      return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
    }

    // Resize handler
    const resize = () => {
      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
      gl.viewport(0, 0, canvas.width, canvas.height);
    };

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);
    resize();

    // Animation loop
    let frameCount = 0;
    let lastFpsTime = performance.now();
    let animationId: number;

    const render = (time: number) => {
      const t = time * 0.001;

      // Auto-rotation when idle
      if (performance.now() - lastInteractionRef.current > 2000) {
        angleYRef.current += 0.003;
      }

      // Clear
      gl.clearColor(0.039, 0.059, 0.102, 1.0);
      gl.clear(gl.COLOR_BUFFER_BIT);

      gl.useProgram(program);

      // Matrices
      const aspect = canvas.width / canvas.height;
      const proj = perspective(Math.PI / 4, aspect, 0.1, 100);
      let mv = translate(0, 0, -4);
      mv = multiplyMatrices(mv, rotateX(angleXRef.current));
      mv = multiplyMatrices(mv, rotateY(angleYRef.current));

      gl.uniformMatrix4fv(projectionMatrixLoc, false, proj);
      gl.uniformMatrix4fv(modelViewMatrixLoc, false, mv);
      gl.uniform1f(uTimeLoc, t);

      const scanY = Math.sin(t * 0.6) * 1.4;
      gl.uniform1f(uScanYLoc, scanY);
      setScanPercent(Math.round(((scanY + 1.4) / 2.8) * 100));

      // Bind attributes
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
      gl.enableVertexAttribArray(positionLoc);
      gl.vertexAttribPointer(positionLoc, 3, gl.FLOAT, false, 0, 0);

      gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
      gl.enableVertexAttribArray(normalLoc);
      gl.vertexAttribPointer(normalLoc, 3, gl.FLOAT, false, 0, 0);

      gl.bindBuffer(gl.ARRAY_BUFFER, scaleBuffer);
      gl.enableVertexAttribArray(scaleLoc);
      gl.vertexAttribPointer(scaleLoc, 1, gl.FLOAT, false, 0, 0);

      gl.bindBuffer(gl.ARRAY_BUFFER, speedBuffer);
      gl.enableVertexAttribArray(speedLoc);
      gl.vertexAttribPointer(speedLoc, 1, gl.FLOAT, false, 0, 0);

      gl.bindBuffer(gl.ARRAY_BUFFER, noiseBuffer);
      gl.enableVertexAttribArray(noiseLoc);
      gl.vertexAttribPointer(noiseLoc, 1, gl.FLOAT, false, 0, 0);

      gl.drawArrays(gl.POINTS, 0, data.count);

      // FPS counter
      frameCount++;
      if (time - lastFpsTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastFpsTime = time;
      }

      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();
      gl.deleteProgram(program);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      gl.deleteBuffer(positionBuffer);
      gl.deleteBuffer(normalBuffer);
      gl.deleteBuffer(scaleBuffer);
      gl.deleteBuffer(speedBuffer);
      gl.deleteBuffer(noiseBuffer);
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-[55vh] rounded-xl overflow-hidden"
      style={{
        background: "radial-gradient(ellipse at 50% 40%, #0f2433 0%, #0a0f1a 70%)",
        border: "1px solid rgba(45,212,191,0.15)",
        boxShadow: "0 0 40px rgba(45,212,191,0.08)",
      }}
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
      
      {/* Animated scanline overlay */}
      <div 
        className="absolute left-0 right-0 h-[2px] pointer-events-none"
        style={{
          top: `${scanPercent}%`,
          background: "linear-gradient(90deg, transparent, rgba(45,212,191,0.6), transparent)",
          boxShadow: "0 0 20px rgba(45,212,191,0.4)",
        }}
      />

      {/* Corner brackets (SVG) */}
      <svg className="absolute top-4 left-4 w-8 h-8 text-teal-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M4 8V4h4M4 16v4h4" />
      </svg>
      <svg className="absolute top-4 right-4 w-8 h-8 text-teal-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M20 8V4h-4M20 16v4h-4" />
      </svg>
      <svg className="absolute bottom-14 left-4 w-8 h-8 text-teal-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M4 8V4h4M4 16v4h4" />
      </svg>
      <svg className="absolute bottom-14 right-4 w-8 h-8 text-teal-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M20 8V4h-4M20 16v4h-4" />
      </svg>

      {/* HUD overlay */}
      <div className="absolute top-4 left-12 font-mono text-xs text-teal-400 flex items-center gap-2">
        <span className="w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
        <span>POINT CLOUD — LIVE RECONSTRUCTION</span>
      </div>

      <div className="absolute top-4 right-12 font-mono text-xs text-slate-400 flex gap-4">
        <span>FPS: <span className="text-teal-400">{fps}</span></span>
        <span>VERTICES: <span className="text-teal-400">{vertexCount.toLocaleString()}</span></span>
        <span>SCAN: <span className="text-teal-400">{scanPercent}%</span></span>
      </div>

      {/* Stats bar */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-black/60 border-t border-slate-700/50 flex items-center justify-center gap-8 font-mono text-xs text-slate-500">
        <span>POINTS <span className="text-slate-300">20,000</span></span>
        <span className="text-slate-600">|</span>
        <span>SHADER <span className="text-slate-300">GLSL ES 1.0</span></span>
        <span className="text-slate-600">|</span>
        <span>BLEND <span className="text-slate-300">ADDITIVE</span></span>
      </div>
    </div>
  );
}
